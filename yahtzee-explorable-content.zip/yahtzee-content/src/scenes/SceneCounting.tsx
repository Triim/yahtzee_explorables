import { useState } from 'react'
import type { SceneModelProps, Scene } from '@/scaffolding'
import { useTr } from '@/scaffolding'
import './Counting.css'

/* ============================================================
   Section «Counting» — the combinatorics apparatus, built from scratch
   on balls & boxes, exactly as much as the article uses:
   product rule → permutations/factorial → combinations →
   permutations with repeats → stars & bars, and finally the 252 = C(10,5).
   Notation is earned last, never handed down.
   ============================================================ */

const SHAPES = ['●', '▲', '■', '◆']
const COLORS = ['#dc2626', '#2563eb', '#059669', '#d97706']

function factorial(n: number): number {
  let f = 1
  for (let i = 2; i <= n; i++) f *= i
  return f
}
function choose(n: number, k: number): number {
  return factorial(n) / (factorial(k) * factorial(n - k))
}

function Stepper({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  onChange: (v: number) => void
}) {
  return (
    <div className="cnt-stepper">
      <button type="button" onClick={() => onChange(Math.max(min, value - 1))} disabled={value <= min}>
        −
      </button>
      <span className="cnt-stepper-val">
        {value} {label}
      </span>
      <button type="button" onClick={() => onChange(Math.min(max, value + 1))} disabled={value >= max}>
        +
      </button>
    </div>
  )
}

export function CountingModel({ activeBeatId, satisfyGate }: SceneModelProps) {
  const beat = activeBeatId ?? ''
  const tr = useTr()

  const [prodA, setProdA] = useState(3) // shapes
  const [prodB, setProdB] = useState(2) // colors
  const [permN, setPermN] = useState(5)
  const [chosen, setChosen] = useState<Set<number>>(new Set()) // CNT.3 pick from 5
  const [reds, setReds] = useState(3) // CNT.4: reds among 5
  const [boxes, setBoxes] = useState<number[]>([0, 0, 0, 0, 0, 0]) // CNT.5 stars per face
  const [stars10, setStars10] = useState<Set<number>>(new Set()) // CNT.6 which of 10 are stars

  if (beat === 'CNT.7' || beat === '') {
    return <div className="cnt-model cnt-model--empty" />
  }

  /* ---- CNT.1 product rule ---- */
  if (beat === 'CNT.1') {
    return (
      <div className="cnt-model">
        <div className="cnt-row">
          <Stepper label={tr('фигур', 'shapes')} value={prodA} min={2} max={4} onChange={(v) => { setProdA(v); satisfyGate?.() }} />
          <Stepper label={tr('цветов', 'colors')} value={prodB} min={2} max={4} onChange={(v) => { setProdB(v); satisfyGate?.() }} />
        </div>
        <div className="cnt-grid" style={{ gridTemplateColumns: `repeat(${prodA}, 1fr)` }}>
          {Array.from({ length: prodB }, (_, c) =>
            Array.from({ length: prodA }, (_, s) => (
              <span key={`${c}-${s}`} className="cnt-combo" style={{ color: COLORS[c] }}>
                {SHAPES[s]}
              </span>
            ))
          )}
        </div>
        <p className="cnt-readout">
          {prodA} × {prodB} = <strong>{prodA * prodB}</strong> {tr('вариантов', 'options')}
        </p>
      </div>
    )
  }

  /* ---- CNT.2 permutations / factorial ---- */
  if (beat === 'CNT.2') {
    const slots = Array.from({ length: permN }, (_, i) => permN - i)
    return (
      <div className="cnt-model">
        <Stepper label={tr('предметов', 'items')} value={permN} min={2} max={6} onChange={(v) => { setPermN(v); satisfyGate?.() }} />
        <div className="cnt-slots">
          {slots.map((c, i) => (
            <span key={i} className="cnt-slot">
              <span className="cnt-slot-box">{i + 1}</span>
              <span className="cnt-slot-cnt">{c}</span>
            </span>
          ))}
        </div>
        <p className="cnt-readout">
          {slots.join(' × ')} = {permN}! = <strong>{factorial(permN)}</strong> {tr('перестановок', 'orderings')}
        </p>
      </div>
    )
  }

  /* ---- CNT.3 combinations ---- */
  if (beat === 'CNT.3') {
    const k = chosen.size
    const toggle = (i: number) =>
      setChosen((prev) => {
        const n = new Set(prev)
        if (n.has(i)) n.delete(i)
        else n.add(i)
        return n
      })
    return (
      <div className="cnt-model">
        <div className="cnt-chips">
          {[0, 1, 2, 3, 4].map((i) => (
            <button
              key={i}
              type="button"
              className={`cnt-chip ${chosen.has(i) ? 'cnt-chip--on' : ''}`}
              onClick={() => { toggle(i); satisfyGate?.() }}
            >
              {i + 1}
            </button>
          ))}
        </div>
        <p className="cnt-readout">
          {k === 0
            ? tr('выбери несколько из пяти', 'pick some of the five')
            : (
              <>
                {tr('выбрать', 'choose')} {k} {tr('из', 'of')} 5 = {' '}
                <strong>{choose(5, k)}</strong> {tr('наборов', 'sets')} ={' '}
                {k === 0 || k === 5 ? '1' : `${5 * 4 * 3 * 2 * 1 / factorial(5 - k)}/${k}!`}
              </>
            )}
        </p>
      </div>
    )
  }

  /* ---- CNT.4 permutations with repeats ---- */
  if (beat === 'CNT.4') {
    const blues = 5 - reds
    const distinct = factorial(5) / (factorial(reds) * factorial(blues))
    return (
      <div className="cnt-model">
        <Stepper label={tr('красных', 'reds')} value={reds} min={1} max={4} onChange={(v) => { setReds(v); satisfyGate?.() }} />
        <div className="cnt-balls">
          {Array.from({ length: reds }, (_, i) => (
            <span key={`r${i}`} className="cnt-ball" style={{ background: COLORS[0] }} />
          ))}
          {Array.from({ length: blues }, (_, i) => (
            <span key={`b${i}`} className="cnt-ball" style={{ background: COLORS[1] }} />
          ))}
        </div>
        <p className="cnt-readout">
          5! / ({reds}! · {blues}!) = 120 / {factorial(reds) * factorial(blues)} ={' '}
          <strong>{distinct}</strong> {tr('различимых', 'distinct')}
        </p>
      </div>
    )
  }

  /* ---- CNT.5 stars & bars ---- */
  if (beat === 'CNT.5') {
    const total = boxes.reduce((s, b) => s + b, 0)
    const addStar = (face: number) => {
      if (total >= 5) return
      setBoxes((prev) => {
        const n = [...prev]
        n[face] += 1
        if (n.reduce((s, b) => s + b, 0) >= 5) satisfyGate?.()
        return n
      })
    }
    // encode as a row of stars and bars
    const row = boxes.map((b) => '★'.repeat(b)).join('|')
    return (
      <div className="cnt-model">
        <div className="cnt-boxes">
          {boxes.map((b, f) => (
            <button key={f} type="button" className="cnt-box" onClick={() => addStar(f)}>
              <span className="cnt-box-face">{f + 1}</span>
              <span className="cnt-box-stars">{'★'.repeat(b)}</span>
            </button>
          ))}
        </div>
        <p className="cnt-encoded">{row || '|||||'}</p>
        <p className="cnt-readout">
          {total < 5
            ? tr(`${total} из 5 звёзд разложено — кликай по граням`, `${total} of 5 stars placed — click the faces`)
            : tr('рука ↔ один ряд из звёзд и перегородок', 'a hand ↔ one row of stars and bars')}
        </p>
        {total > 0 && (
          <button type="button" className="cnt-btn" onClick={() => setBoxes([0, 0, 0, 0, 0, 0])}>
            {tr('сбросить', 'reset')}
          </button>
        )}
      </div>
    )
  }

  /* ---- CNT.6 choose 5 of 10 → 252 ---- */
  if (beat === 'CNT.6') {
    const k = stars10.size
    const toggle = (i: number) =>
      setStars10((prev) => {
        const n = new Set(prev)
        if (n.has(i)) n.delete(i)
        else if (n.size < 5) n.add(i)
        else return prev
        return n
      })
    // decode the chosen positions into the six boxes (bars split the 10 slots)
    return (
      <div className="cnt-model">
        <div className="cnt-row10">
          {Array.from({ length: 10 }, (_, i) => (
            <button
              key={i}
              type="button"
              className={`cnt-slot10 ${stars10.has(i) ? 'cnt-slot10--star' : 'cnt-slot10--bar'}`}
              onClick={() => { toggle(i); if (stars10.size >= 4) satisfyGate?.() }}
            >
              {stars10.has(i) ? '★' : '|'}
            </button>
          ))}
        </div>
        <p className="cnt-readout">
          {k < 5
            ? tr(`${k} из 5 звёзд выбрано — какие 5 из 10 позиций?`, `${k} of 5 stars chosen — which 5 of 10 positions?`)
            : (
              <>
                {tr('выбрать 5 из 10', 'choose 5 of 10')} ={' '}
                <strong>{choose(10, 5)}</strong> {tr('рук', 'hands')}
              </>
            )}
        </p>
      </div>
    )
  }

  return <div className="cnt-model cnt-model--empty" />
}

export const sceneCounting: Scene = {
  id: 'scene-counting',
  model: CountingModel,
  beats: [
    {
      id: 'CNT.1',
      scene: 'scene-counting',
      prompt:
        'Чтобы из 7776 добраться до 252, нужен счёт. Соберём его инструмент с нуля — на шарах и коробках. Первое правило ты уже видел: меняй число фигур и цветов.',
      payoff:
        'Каждый независимый выбор умножает число вариантов: фигура и цвет дают «фигур × цветов». Два кубика — 6×6, пять — $6^5$.\n[[правило произведения: независимые выборы перемножаются]]\nС него весь аппарат и вырастает.',
      gate: { kind: 'choice' },
    },
    {
      id: 'CNT.2',
      scene: 'scene-counting',
      prompt:
        'Сколькими способами выстроить несколько разных предметов в ряд по местам? Меняй их число и смотри.',
      payoff:
        'На первое место — все кандидаты, на второе остаётся на одного меньше, и так далее. Перемножаем убывающие числа:\n[[$5! = 5\\cdot4\\cdot3\\cdot2\\cdot1 = 120$]]\nЧисло способов упорядочить $n$ различных предметов — это **факториал** $n!$, а сами упорядочивания — **перестановки**.',
      gate: { kind: 'choice' },
    },
    {
      id: 'CNT.3',
      scene: 'scene-counting',
      prompt:
        'А если порядок не важен — сколькими способами просто ВЫБРАТЬ часть из пяти? Отметь несколько.',
      payoff:
        'Выбрать 2 из 5 по порядку — это $5\\cdot4=20$ способов, но «первый-второй» и «второй-первый» дают один и тот же набор, поэтому делим на $2!$.\n[[$\\binom{5}{2} = \\dfrac{5\\cdot4}{2!} = 10$]]\nВыбор без порядка называют **сочетанием** $\\binom{n}{k}$ — «$n$ по $k$».',
      gate: { kind: 'choice' },
    },
    {
      id: 'CNT.4',
      scene: 'scene-counting',
      prompt:
        'Ещё случай: часть предметов одинаковы. Поменяй местами два одинаковых шара — ничего не изменится. Меняй, сколько шаров красные.',
      payoff:
        'Пять мест дают $5! = 120$ расстановок, но перестановки одинаковых шаров между собой неразличимы. Делим на перестановки внутри каждого цвета:\n[[$\\dfrac{5!}{3!\\,2!} = \\dfrac{120}{12} = 10$]]\nЭто **перестановки с повторами**.',
      gate: { kind: 'choice' },
    },
    {
      id: 'CNT.5',
      scene: 'scene-counting',
      prompt:
        'Теперь главный приём. Рука — это сколько каких граней: пять одинаковых звёзд разложи по шести коробкам-граням.',
      payoff:
        'Запиши раскладку одним рядом: звёзды по коробкам, а между шестью коробками — пять перегородок. ★★|·|★|★|·|★ — это рука «две единицы, одна тройка, одна четвёрка, одна шестёрка».\n[[любая рука ↔ один ряд из 5 звёзд и 5 перегородок]]\nЭтот приём — **звёзды и перегородки**.',
      gate: { kind: 'choice' },
    },
    {
      id: 'CNT.6',
      scene: 'scene-counting',
      prompt:
        'У ряда всегда 10 позиций: 5 звёзд и 5 перегородок. Вся рука — это просто выбор, какие 5 из 10 позиций отдать звёздам. Выбери.',
      payoff:
        'А выбор без порядка мы уже умеем считать — это сочетание:\n[[$\\binom{10}{5} = \\dfrac{10\\cdot9\\cdot8\\cdot7\\cdot6}{5!} = 252$]]\nВот откуда берётся 252 — не с потолка, а собрано руками. В общем виде «$k$ шаров по $m$ коробкам» — это $\\binom{m+k-1}{k}$, здесь $\\binom{6+5-1}{5}$.',
      gate: { kind: 'choice' },
    },
    {
      id: 'CNT.7',
      scene: 'scene-counting',
      prompt:
        'Итак, 252 руки сосчитаны. Но сосчитать — не значит уравнять: за разными руками прячется разное число раскладов. Посмотрим, сколько именно.',
    },
  ],
}
