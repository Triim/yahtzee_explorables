# Yahtzee — interactive explorable explanation of probability theory

This is the **substantive source** of an interactive "explorable explanation": a long-form,
scrollable article that teaches probability theory from scratch using the dice game **Yahtzee
(Яцзы)**. It is bilingual (Russian = primary, English = secondary) and built with
**React 19 + TypeScript + Vite**.

> This archive contains only the content/code. Authoring prompts, design specs, dev-process
> docs, the binary font, `node_modules`, and build output are intentionally omitted.

## The reading model

The page is a two-column experience:

- **Left column** — the prose, delivered as a vertical sequence of **beats**. Each beat has a
  `prompt` (one line shown first) and usually a `payoff` (revealed after the reader interacts).
- **Right panel** — a **fixed interactive "model"** whose content swaps as you scroll. The model
  is what you *touch*; the prose leads you through it.
- **Gates** — a beat may be locked behind an interaction (`roll`, `slider`, `choice`, `hold`,
  `toggle`); the payoff and the next beat unlock once the reader does the thing. The guiding
  principle is **"touch it, then name it"**: a concept gets its formal name only after the reader
  has seen/manipulated it, and a new concept appears only when the previous tool visibly breaks.

## Where the content actually lives

- **The teaching text** = the `prompt`/`payoff` strings inside each `src/scenes/Scene*.tsx`
  (Russian is the source of truth) **plus** `src/i18n/en.ts` (English overrides, keyed by beat id).
  `src/i18n/strings.ts` holds UI chrome + the section menu titles.
- **The interactive models** = the React components in the same `src/scenes/Scene*.tsx` files.
- **The math** = `src/engine/` (scoring, expected value, the optimal-play oracle ≈ 254.6,
  Monte-Carlo tournaments, distributions, combinatorics).

Beat text uses a tiny markup understood by `src/scaffolding/RichText.tsx`:
`**bold**` for an earned term, `$…$` / `$$…$$` for KaTeX math, `[[ … ]]` for a highlighted
formula/callout line, and `\n` for line breaks.

## Architecture

- `src/scaffolding/` — the engine of the experience: `BeatContext`, `BeatTrack` (scroll → active
  beat), `ActiveSceneRenderer` (the fixed right stage), `SectionHeroes`/`HeroTitle` (title
  curtains), `NavMenu` (progress rail), `RichText`, `Formula` (KaTeX), `XkcdChart` (sketchy
  charts, theme-aware), `SettingsContext` (lang + light/dark), `PlayerStateContext` (persists the
  tutorial game so later sections can call back to it). `types.ts` defines `Scene`/`Beat`/`Gate`.
- `src/scenes/` — one file per section: a model component + an exported `scene` object
  (`{ id, model, beats[] }`). `*.css` are per-scene styles.
- `src/engine/` — pure game/probability logic (no UI), reused by several scenes + a Web Worker
  (`src/worker/montecarlo.worker.ts`) for non-blocking Monte-Carlo runs.
- `src/components/` — the `Die`, charts, dice-roll hook, face colors.
- `src/App.tsx` — assembles the ordered list of scenes (this is the table of contents).

## The curriculum (order of sections)

0. **Intro** + **Tutorial** — play one real game of Yahtzee first, no math. The finished
   scorecard is saved and referenced later.
1. What does "probable" mean? — sample space, **event**, probability, law of large numbers,
   independence/dependence, the 6×6 grid (P = favorable / all), normalization Σ = 1.
2. Which sums come up more often? — the sum distribution, **convolution** (spread-and-stack),
   generating functions, the bell via the **central limit theorem**.
3. How many outcomes are there? — the product rule built up to 6⁵ = 7776; hand as a **multiset/state**.
4. Where does 252 come from? — combinatorics from scratch on balls & boxes (product rule →
   factorial/permutations → combinations → permutations with repeats → **stars and bars** →
   C(10,5) = 252, notation earned last).
5. Are all hands equally likely? — multinomial weights; 252 hands vs 7776 equally-likely orderings.
6. How is it scored? — the 13 categories; counting their odds (e.g. 3125 = 5⁵, the binomial
   B(5, 1/6), a first look at linearity of expectation).
7. What's better to keep? — rerolls and **conditional probability**; competing targets.
8. What's a hand worth on average? — random variable, **expected value** E[X] = Σ x·P(x).
9. Why does "grab the max" lose? — **linearity of expectation** for the whole game; the greedy
   player; bonus threshold and irreversibility break the naive recipe.
10. What is each position worth? — game **state**, value **V(s)**, choice/chance nodes,
    backward induction; the optimal-play ceiling ≈ 254.6.
11. How spread out are the scores? — Monte-Carlo; the score distribution's μ and σ (variance).
12. How do you even play? — practical strategy; archetypes (μ, σ).
13. What does the opponent change? — objective shifts from "max score" to "beat them"; risk.
14. Skill or luck? — synthesis; how much each contributes.
- Side-quest: Is the die fair? — χ²-test and a derived Bayes update (enrichment, parked at the end).

## Running it (optional)

```
npm install
npm run dev      # vite dev server
npm run build    # type-check + production build
```

Note: the hand-drawn **xkcd font** binary is omitted to save space, so charts/headings fall back
to a default font; this is purely cosmetic and does not affect the content or logic.
