import { useState } from 'react'
import type { SceneModelProps, Scene } from '@/scaffolding'
import { XkcdChart, Formula, useTr } from '@/scaffolding'
import './Fairness.css'

/* ============================================================
   Section «Is the die fair?» — the inverse question.
   Goodness-of-fit: observed face counts vs the uniform expectation,
   the chi-square statistic and its 5% threshold, and a Bayes update.
   ============================================================ */

const ACCENT = '#6366f1'
const LOADED = [0, 0.14, 0.14, 0.14, 0.14, 0.14, 0.3] // index by face; six is heavy
const CHI_CRIT = 11.07 // chi-square, 5 d.f., 5%

function chiSquare(counts: number[], total: number): number {
  if (total === 0) return 0
  const e = total / 6
  let s = 0
  for (let f = 1; f <= 6; f++) s += ((counts[f] - e) ** 2) / e
  return s
}

/** Posterior P(loaded) from a fair-vs-loaded likelihood ratio, prior 0.5. */
function posteriorLoaded(counts: number[], total: number): number {
  if (total === 0) return 0.5
  let logFair = 0
  let logLoaded = 0
  for (let f = 1; f <= 6; f++) {
    logFair += counts[f] * Math.log(1 / 6)
    logLoaded += counts[f] * Math.log(LOADED[f])
  }
  return 1 / (1 + Math.exp(logFair - logLoaded))
}

export function FairnessModel({ activeBeatId, satisfyGate }: SceneModelProps) {
  const beat = activeBeatId ?? ''
  const tr = useTr()
  const [loaded, setLoaded] = useState(false)
  const [counts, setCounts] = useState<number[]>([0, 0, 0, 0, 0, 0, 0])
  const [total, setTotal] = useState(0)

  if (beat === 'FAIR.4' || beat === '') {
    return <div className="fair-model fair-model--empty" />
  }

  const rollBatch = () => {
    const add = [0, 0, 0, 0, 0, 0, 0]
    for (let i = 0; i < 200; i++) {
      const r = Math.random()
      let face = 6
      if (loaded) {
        let acc = 0
        for (let f = 1; f <= 6; f++) {
          acc += LOADED[f]
          if (r < acc) { face = f; break }
        }
      } else {
        face = (r * 6 | 0) + 1
      }
      add[face]++
    }
    setCounts((c) => c.map((v, f) => v + add[f]))
    setTotal((t) => {
      const nt = t + 200
      if (nt >= 600) satisfyGate?.()
      return nt
    })
  }

  const reset = (next: boolean) => {
    setLoaded(next)
    setCounts([0, 0, 0, 0, 0, 0, 0])
    setTotal(0)
  }

  const chi = chiSquare(counts, total)
  const suspect = chi > CHI_CRIT
  const post = posteriorLoaded(counts, total)
  const expected = total / 6

  return (
    <div className="fair-model">
      <div className="fair-switch">
        <button
          className={`fair-opt ${!loaded ? 'fair-opt--on' : ''}`}
          onClick={() => reset(false)}
        >
          {tr('честная', 'fair')}
        </button>
        <button
          className={`fair-opt ${loaded ? 'fair-opt--on' : ''}`}
          onClick={() => reset(true)}
        >
          {tr('подкручена', 'loaded')}
        </button>
      </div>

      {total > 0 && (
        <XkcdChart
          type="Bar"
          width={360}
          height={190}
          config={{
            xLabel: tr('грань', 'face'),
            yLabel: tr('выпало', 'count'),
            data: {
              labels: ['1', '2', '3', '4', '5', '6'],
              datasets: [{ data: [1, 2, 3, 4, 5, 6].map((f) => counts[f]) }],
            },
            options: { yTickCount: 3, dataColors: [1, 2, 3, 4, 5, 6].map(() => ACCENT) },
          }}
        />
      )}

      <button type="button" className="fair-btn" onClick={rollBatch}>
        +200 {tr('бросков', 'rolls')}
      </button>

      <p className="fair-readout">
        {total} {tr('бросков', 'rolls')}
        {total > 0 && <> · {tr('ждём по', 'expect')} {expected.toFixed(0)} {tr('на грань', 'per face')}</>}
      </p>

      {/* FAIR.2 / FAIR.3 — the chi-square verdict */}
      {(beat === 'FAIR.2' || beat === 'FAIR.3') && total > 0 && (
        <div className="fair-chi">
          <Formula latex={`\\chi^2 = ${chi.toFixed(1)}`} />
          <span className={`fair-verdict ${suspect ? 'fair-verdict--bad' : 'fair-verdict--ok'}`}>
            {suspect
              ? tr(`> ${CHI_CRIT} · под подозрением`, `> ${CHI_CRIT} · suspicious`)
              : tr(`< ${CHI_CRIT} · похоже на честную`, `< ${CHI_CRIT} · looks fair`)}
          </span>
        </div>
      )}

      {/* FAIR.3 — Bayes posterior */}
      {beat === 'FAIR.3' && (
        <div className="fair-bayes">
          <div className="fair-bayes-track">
            <div className="fair-bayes-fill" style={{ width: `${(post * 100).toFixed(0)}%` }} />
          </div>
          <span className="fair-bayes-label">
            P({tr('подкручена', 'loaded')}) ≈ {post.toFixed(2)}
          </span>
        </div>
      )}
    </div>
  )
}

export const sceneFair: Scene = {
  id: 'scene-fair',
  model: FairnessModel,
  beats: [
    {
      id: 'FAIR.1',
      scene: 'scene-fair',
      prompt:
        'Всю дорогу мы верили кости на слово: шесть равновероятных граней. А если она подкручена — как вообще это заметить? Тайно выбери кость и накидай бросков.',
      payoff:
        'На горстке бросков перекос не виден — случай шумит, ровно как в Разделе 1. Нужна мера: насколько сильно наблюдаемые частоты граней расходятся с ожидаемыми $n/6$. Пока счёт мал, и честная кость гуляет туда-сюда.',
      gate: { kind: 'choice' },
    },
    {
      id: 'FAIR.2',
      scene: 'scene-fair',
      prompt: 'Эту меру расхождения даёт один критерий. Накидай побольше — и следи за ним.',
      payoff:
        'Это **критерий хи-квадрат**: $\\chi^2 = \\sum \\frac{(O-E)^2}{E}$ — сумма квадратов отклонений наблюдаемого $O$ от ожидаемого $E$, нормированных на ожидание. Для честной кости с шестью гранями есть порог: расхождение с $\\chi^2 > 11{,}07$ у честной кости случается реже, чем в 5 % случаев. Перешагнул порог — кость под подозрением.',
      gate: { kind: 'choice' },
    },
    {
      id: 'FAIR.3',
      scene: 'scene-fair',
      prompt: 'Порог — это «да/нет». А уверенность можно копить числом.',
      payoff:
        'Это **проверка гипотез** наизнанку, по **формуле Байеса**: каждый бросок чуть сдвигает оценку «кость подкручена» к той гипотезе, под которую он лучше ложится. Чем больше бросков, тем твёрже вердикт — хотя честная кость порой и поводит у самого порога. Так из частот рождается суждение о самой кости.',
      gate: { kind: 'choice' },
    },
    {
      id: 'FAIR.4',
      scene: 'scene-fair',
      prompt:
        'Круг замкнулся: мы не только считаем шансы по честной кости, но и умеем проверить саму честность. Стол честный — пора посадить за него соперника.',
    },
  ],
}
