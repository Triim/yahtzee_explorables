import { useState } from 'react'
import type { SceneModelProps, Scene } from '@/scaffolding'
import { XkcdChart, Formula, useTr } from '@/scaffolding'
import { Die } from '@/components'
import './Multiset.css'

/* ============================================================
   Section «Counting hands» — multiset, stars & bars, multinomial.
   How many of the 7776 ordered rolls map to one hand, and why the
   252 hands are NOT equally likely (the bridge §2 → §3).
   ============================================================ */

const ACCENT = '#6366f1'

interface Sample {
  ru: string
  en: string
  hand: number[]
}
const SAMPLES: Sample[] = [
  { ru: 'всё разные', en: 'all different', hand: [1, 2, 3, 4, 5] },
  { ru: 'пара', en: 'one pair', hand: [3, 1, 6, 1, 4] },
  { ru: 'фулл-хаус', en: 'full house', hand: [4, 4, 4, 2, 2] },
  { ru: 'Yahtzee', en: 'Yahtzee', hand: [5, 5, 5, 5, 5] },
]

function counts(hand: number[]): number[] {
  const c = [0, 0, 0, 0, 0, 0, 0]
  hand.forEach((v) => c[v]++)
  return c
}
function fact(k: number): number {
  let f = 1
  for (let i = 2; i <= k; i++) f *= i
  return f
}
/** Multinomial coefficient: how many ordered rolls map to this hand. */
function weight(hand: number[]): number {
  const c = counts(hand)
  let den = 1
  for (let f = 1; f <= 6; f++) den *= fact(c[f])
  return fact(5) / den
}

/** Stars-and-bars string for a hand: stars per face, bars between the six faces. */
function starsAndBars(hand: number[]): string {
  const c = counts(hand)
  return [1, 2, 3, 4, 5, 6].map((f) => '★'.repeat(c[f])).join('|')
}

export function MultisetModel({ activeBeatId, satisfyGate }: SceneModelProps) {
  const beat = activeBeatId ?? ''
  const tr = useTr()
  const [idx, setIdx] = useState(1)
  const [equal, setEqual] = useState(true)

  if (beat === 'MUL.4' || beat === '') {
    return <div className="mset-model mset-model--empty" />
  }

  const sample = SAMPLES[idx]
  const w = weight(sample.hand)

  return (
    <div className="mset-model">
      <div className="mset-hand">
        {sample.hand.map((v, i) => (
          <Die key={i} value={v} size={52} />
        ))}
      </div>

      {/* pattern picker (MUL.1 / MUL.3) */}
      {beat !== 'MUL.2' && (
        <div className="mset-pick">
          {SAMPLES.map((s, i) => (
            <button
              key={s.en}
              className={`mset-pick-btn ${i === idx ? 'mset-pick-btn--on' : ''}`}
              onClick={() => {
                setIdx(i)
                satisfyGate?.()
              }}
            >
              {tr(s.ru, s.en)}
            </button>
          ))}
        </div>
      )}

      {/* MUL.1 — the multinomial weight */}
      {beat === 'MUL.1' && (
        <div className="mset-weight">
          <span className="mset-weight-num">{w}</span>
          <span className="mset-weight-label">
            {w === 1 ? tr('расклад', 'ordering') : tr('раскладов из 7776', 'orderings of 7776')}
          </span>
        </div>
      )}

      {/* MUL.2 — stars & bars */}
      {beat === 'MUL.2' && (
        <>
          <div className="mset-stars">{starsAndBars(sample.hand)}</div>
          <Formula latex="\binom{10}{5} = 252" />
        </>
      )}

      {/* MUL.3 — the 252 are NOT equally likely */}
      {beat === 'MUL.3' && (
        <>
          <button
            type="button"
            className={`mset-toggle ${equal ? '' : 'mset-toggle--on'}`}
            onClick={() => {
              setEqual((e) => !e)
              satisfyGate?.()
            }}
          >
            {equal ? tr('равновероятны?', 'equally likely?') : tr('нет — взвесь по раскладам', 'no — weight by orderings')}
          </button>
          {!equal && (
            <XkcdChart
              type="Bar"
              width={360}
              height={190}
              config={{
                xLabel: '',
                yLabel: tr('раскладов', 'orderings'),
                data: {
                  labels: SAMPLES.map((s) => tr(s.ru, s.en)),
                  datasets: [{ data: SAMPLES.map((s) => weight(s.hand)) }],
                },
                options: { yTickCount: 3, dataColors: SAMPLES.map(() => ACCENT) },
              }}
            />
          )}
          <p className="mset-note">
            {equal
              ? tr('252 руки — но клик покажет, честно ли это', '252 hands — but click to see if that’s fair')
              : tr('Σ всех весов = 7776', 'Σ of all weights = 7776')}
          </p>
        </>
      )}
    </div>
  )
}

export const sceneMultiset: Scene = {
  id: 'scene-multiset',
  model: MultisetModel,
  beats: [
    {
      id: 'MUL.1',
      scene: 'scene-multiset',
      prompt:
        'Только что 7776 раскладов схлопнулись в 252 руки. Но сколько именно раскладов прячется за одной рукой? Выбери руку — и посчитаем, сколькими способами её можно разложить по местам.',
      payoff:
        'Сколько по-разному расставить пять костей по позициям — это **мультиномиальный коэффициент** $\\frac{5!}{n_1!\\,n_2!\\cdots n_6!}$. Для всё-разной руки это $5! = 120$ раскладов; для пары — 60; а для Yahtzee — ровно один: как ни переставляй пять пятёрок, расклад не меняется.',
      gate: { kind: 'choice' },
    },
    {
      id: 'MUL.2',
      scene: 'scene-multiset',
      prompt: 'А откуда вообще берётся само число 252?',
      payoff:
        'Рука — это сколько единиц, двоек, …, шестёрок, всего пять штук. Закодируй её как пять звёзд (кости) и пять перегородок (границы между шестью гранями): $\\bigstar\\bigstar|\\,|\\bigstar|\\bigstar|\\,|\\bigstar$. Любая расстановка 5 звёзд среди 10 позиций — это ровно одна рука, и их $\\binom{10}{5} = 252$. Этот приём называют **«звёзды и перегородки»**.',
    },
    {
      id: 'MUL.3',
      scene: 'scene-multiset',
      prompt:
        'Раз за разными руками стоит разное число раскладов — значит, и шансы у них разные. Проверь.',
      payoff:
        'Каждая рука весит ровно столько, сколько за ней упорядоченных раскладов: Yahtzee — 1 из 7776, всё-разное — 120 из 7776, в сто двадцать раз чаще. Сложи веса всех 252 рук — получишь обратно 7776. Это та же история, что с суммой на сетке 6×6: к семёрке вело больше дорог. Поэтому **шансы считают по 7776 равновероятным раскладам**, а 252 руки — удобные ярлыки, а не равные доли.',
      gate: { kind: 'toggle' },
    },
    {
      id: 'MUL.4',
      scene: 'scene-multiset',
      prompt:
        'Значит, у руки два лица: 252 состояния — чтобы думать и выбирать, 7776 раскладов — чтобы считать шансы. С этим различением и разберём, чего рука стоит. Пора к правилам Yahtzee.',
    },
  ],
}
