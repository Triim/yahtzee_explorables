import { useEffect, useState } from 'react'
import type { SceneModelProps, Scene } from '@/scaffolding'
import { XkcdChart, Formula, useTr } from '@/scaffolding'
import './SumDice.css'

/* ============================================================
   Section «Sum of the dice» — convolution / generating functions.
   The sum distribution of n dice, built up one die at a time, is an
   exact convolution; its shape tends to a bell (CLT).
   ============================================================ */

const ACCENT = '#6366f1'

/** Exact distribution of the sum of n dice (convolution of the uniform die). */
function sumDist(n: number): number[] {
  // cur[s] = probability the running sum equals s
  let cur = [0, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6, 1 / 6]
  for (let k = 2; k <= n; k++) {
    const next = new Array(cur.length + 6).fill(0)
    for (let s = 0; s < cur.length; s++) {
      if (cur[s] > 0) for (let f = 1; f <= 6; f++) next[s + f] += cur[s] / 6
    }
    cur = next
  }
  return cur
}

/** {sum, percent} bars, with labels thinned for wide ranges. */
function bars(n: number): { labels: string[]; data: number[] } {
  const dist = sumDist(n)
  const labels: string[] = []
  const data: number[] = []
  const dense = 6 * n - n > 13
  for (let s = n; s <= 6 * n; s++) {
    labels.push(dense ? (s % 5 === 0 ? String(s) : '') : String(s))
    data.push(+(dist[s] * 100).toFixed(1))
  }
  return { labels, data }
}

export function SumDiceModel({ activeBeatId, satisfyGate }: SceneModelProps) {
  const beat = activeBeatId ?? ''
  const tr = useTr()
  const [n, setN] = useState(1)

  // The dice count persists across beats; if five were reached early, SUM.3's
  // gate would have nothing to click — satisfy it directly once we're there.
  useEffect(() => {
    if (beat === 'SUM.3' && n >= 5) satisfyGate?.()
  }, [beat, n, satisfyGate])

  if (beat === 'SUM.4' || beat === '') {
    return <div className="sum-model sum-model--empty" />
  }

  const { labels, data } = bars(n)
  const lo = n
  const hi = 6 * n
  const mid = (lo + hi) / 2

  const addDie = () => {
    setN((k) => {
      const nk = Math.min(k + 1, 5)
      if (beat === 'SUM.1' ? nk >= 2 : nk >= 5) satisfyGate?.()
      return nk
    })
  }

  return (
    <div className="sum-model">
      <div className="sum-dice-count">
        {Array.from({ length: n }, (_, i) => (
          <span key={i} className="sum-pip" />
        ))}
        <span className="sum-n">{n} {n === 1 ? tr('кость', 'die') : tr('костей', 'dice')}</span>
      </div>

      <XkcdChart
        type="Bar"
        width={Math.min(120 + (hi - lo) * 16, 440)}
        height={210}
        config={{
          xLabel: tr('сумма', 'sum'),
          yLabel: '%',
          data: { labels, datasets: [{ data }] },
          options: { yTickCount: 3, dataColors: data.map(() => ACCENT) },
        }}
      />

      {beat === 'SUM.2' && (
        <div className="sum-formula">
          <Formula latex={`(x + x^2 + \\dots + x^6)^{${n}}`} />
        </div>
      )}

      <p className="sum-readout">
        {tr('диапазон', 'range')} {lo}…{hi}
        {n >= 2 && <> · {tr('центр', 'center')} {mid}</>}
      </p>

      {beat !== 'SUM.2' && (
        <button type="button" className="sum-btn" onClick={addDie} disabled={n >= 5}>
          {n >= 5 ? tr('пять костей', 'five dice') : tr('добавить кость', 'add a die')}
        </button>
      )}
    </div>
  )
}

export const sceneSum: Scene = {
  id: 'scene-sum',
  model: SumDiceModel,
  beats: [
    {
      id: 'SUM.1',
      scene: 'scene-sum',
      prompt:
        'Колокол из прошлого раздела — это сумма двух костей. А если костей больше? Добавляй по одной и смотри на форму.',
      payoff:
        'Одна кость плоская — шесть равновероятных граней. Две дают треугольник. Каждая новая кость **сворачивается** с тем, что уже есть: новая сумма — это старая сумма плюс выпавшая грань, и вероятности перемножаются и складываются. Эту операцию над распределениями называют **свёрткой**.',
      gate: { kind: 'choice' },
    },
    {
      id: 'SUM.2',
      scene: 'scene-sum',
      prompt: 'У этого сложения есть компактная запись.',
      payoff:
        'Распределение суммы — это коэффициенты многочлена $(x + x^2 + \\dots + x^6)^n$: раскрой скобки — и при каждой степени $x^s$ соберётся ровно столько слагаемых, сколькими способами набирается сумма $s$. Такой многочлен называют **производящей функцией**, а умножение скобок — это та же свёртка, только на языке алгебры.',
    },
    {
      id: 'SUM.3',
      scene: 'scene-sum',
      prompt: 'Доведи до пяти костей и посмотри на итоговую форму.',
      payoff:
        'Сумма пяти костей живёт на отрезке $5\\dots30$, симметрична относительно $17{,}5$, с вершиной на 17 и 18. И чем больше костей складываешь, тем глаже выходит колокол — независимо от того, что отдельная кость плоская. Это **центральная предельная теорема**: сумма многих независимых слагаемых тянется к нормальному распределению.',
      gate: { kind: 'choice' },
    },
    {
      id: 'SUM.4',
      scene: 'scene-sum',
      prompt:
        'Но у суммы есть слепое пятно: она стирает, какие именно грани выпали. 6·6·1·1·1 и 3·3·3·3·3 дают одно и то же — 15. А игре важна не сумма, а сама рука. Возьмём пять костей как единый объект.',
    },
  ],
}
